<div id="footer" role="contentinfo">
    <p><a href="<?php echo get_option('home'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></p>
    <p>A theme designed by <a href="http://benmartineau.com/" target="_blank" title="Ben Martineau">Ben Martineau</a></p>
    <p><a href="<?php bloginfo('rss2_url'); ?>">Subscribe RSS</a></p>
</div>

